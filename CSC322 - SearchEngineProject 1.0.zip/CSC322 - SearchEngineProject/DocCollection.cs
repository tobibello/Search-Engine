﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CSC322_SearchEngineProject
{
    [Serializable]
    internal class DocCollection : IDictionary<decimal, Document>//should be FileInfo
    {
        private readonly Dictionary<decimal, Document> _collection;

        internal DocCollection()
        {
            _collection = new Dictionary<decimal, Document>();
        }

        public Document this[decimal key]
        {
            get
            {
                return _collection[key];
            }

            set
            {
                _collection[key] = value;
            }
        }

        public int Count => _collection.Count;

        public bool IsReadOnly => ((IDictionary<decimal, Document>)_collection).IsReadOnly;

        public ICollection<decimal> Keys => ((IDictionary<decimal, Document>)_collection).Keys;

        public ICollection<Document> Values => ((IDictionary<decimal, Document>)_collection).Values;

        public void Add(KeyValuePair<decimal, Document> item)
        {
            ((IDictionary<decimal, Document>)_collection).Add(item);
        }

        public void Add(decimal key, Document value)
        {
            _collection.Add(key, value);
        }

        public void Clear()
        {
            _collection.Clear();
        }

        public bool Contains(KeyValuePair<decimal, Document> item)
        {
            return ((IDictionary<decimal, Document>)_collection).Contains(item);
        }

        public bool ContainsKey(decimal key)
        {
            return _collection.ContainsKey(key);
        }

        public void CopyTo(KeyValuePair<decimal, Document>[] array, int arrayIndex)
        {
            ((IDictionary<decimal, Document>)_collection).CopyTo(array, arrayIndex);
        }

        public IEnumerator<KeyValuePair<decimal, Document>> GetEnumerator()
        {
            return ((IDictionary<decimal, Document>)_collection).GetEnumerator();
        }

        public bool Remove(KeyValuePair<decimal, Document> item)
        {
            return ((IDictionary<decimal, Document>)_collection).Remove(item);
        }

        public bool Remove(decimal key)
        {
            return _collection.Remove(key);
        }

        public bool TryGetValue(decimal key, out Document value)
        {
            return _collection.TryGetValue(key, out value);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return ((IDictionary<decimal, Document>)_collection).GetEnumerator();
        }

        public override string ToString()
        {
            string str = "";
            foreach (var pair in _collection)
            {
                str +=
                    $"<doc{pair.Key} : {pair.Value.File.FullName}>";
            }
            return str;
        }
    }
}